
# CreditFusion-XAI: A Leakage-Aware Multi-Dataset Framework for Explainable Credit Default Prediction

**Shimaa M. Abd-Elsalam^1^ and Hosam Eldin Fawzan Sayed^2,*^**

^1^ Systems and Information Department, Institute of Engineering Research and New Renewable Energy, National Research Centre, Giza, Egypt

^2^ Department of Computer Science, Faculty of Computers and Information, Arish University, North Sinai, Egypt

^*^ Corresponding author: Hosam.Fawzan@ci.aru.edu.e

## Abstract

Credit default prediction is a critical task in financial risk management because inaccurate lending decisions can increase institutional losses and weaken the stability of credit services. Although machine-learning models have shown promising results for credit scoring, many studies rely on single datasets, limited preprocessing, or evaluation settings that may overestimate generalization performance. This paper proposes **CreditFusion-XAI**, a leakage-aware multi-dataset framework for explainable credit default prediction. Three public Kaggle credit-risk datasets were standardized, harmonized, merged, and cleaned into a unified structure. The preprocessing pipeline included duplicate removal, missing-value imputation, categorical encoding, feature scaling, and class balancing using SMOTE applied only to the training set. Six machine-learning models were evaluated: Logistic Regression, Decision Tree, Random Forest, HistGradientBoosting, XGBoost, and K-Nearest Neighbors. To provide a more reliable assessment, the experiments used both stratified random validation and leave-one-dataset-out validation. The best stratified-random result was achieved by Random Forest, with 93.16% accuracy, 83.93% F1-score, 79.67% Matthews correlation coefficient, 97.14% ROC-AUC, and 93.02% PR-AUC. Robustness testing showed that performance varied across held-out datasets, highlighting the importance of cross-dataset validation in credit-risk modeling. Explainability analysis using permutation importance identified previous default history, loan interest rate, loan-percent-income ratio, home ownership, loan purpose, and annual income as the most influential predictors. The results demonstrate that careful data integration, leakage-aware preprocessing, and explainable model comparison can improve the reliability of credit default prediction.

**Keywords:** Credit risk prediction; machine learning; credit default; multi-dataset integration; explainable AI; SMOTE; financial risk assessment; Random Forest.

## 1 Introduction

Credit risk assessment is one of the most important analytical tasks in banking and financial decision-making. Financial institutions must evaluate whether applicants are likely to repay loans or default because inaccurate predictions can lead to financial losses, poor portfolio quality, and increased operational risk. Traditional credit-scoring methods usually depend on fixed statistical rules, historical repayment indicators, and expert-defined thresholds. Although these methods are useful, they may be insufficient when borrower behavior becomes more complex and when financial data are large, heterogeneous, and nonlinear [1].

Machine-learning methods provide an effective alternative for credit default prediction because they can learn complex relationships between borrower characteristics and repayment outcomes. Models such as Logistic Regression, Decision Trees, Random Forest, Gradient Boosting, XGBoost, and K-Nearest Neighbors have been applied to credit scoring and loan-default prediction. Recent studies show that ensemble methods frequently outperform single classifiers in credit-risk prediction because they capture nonlinear feature interactions and improve robustness [2].

However, high model accuracy alone is not enough for reliable credit-risk assessment. Credit datasets often contain missing values, outliers, inconsistent column names, and categorical variables that require careful preprocessing. Default cases are also usually fewer than non-default cases, creating class imbalance that may cause models to favor the majority class. Studies that do not address imbalance, data leakage, and validation design may report optimistic results that are difficult to reproduce in real lending environments [3].

Another important limitation is the dependence on a single dataset. A model that performs well under a random split may not generalize to a different dataset or institution. This issue is particularly relevant in credit-risk modeling because data distributions may vary across banks, lending policies, borrower groups, and countries. Therefore, a realistic evaluation should assess both within-distribution performance and cross-dataset robustness [4].

Explainability is also essential in financial decision-making. A credit default model is not useful only because it predicts risk; it must also help analysts understand why an applicant is classified as risky. Explainable artificial intelligence (XAI) methods provide insight into feature contributions and support the transparency needed for credit-risk interpretation [5].

This paper proposes **CreditFusion-XAI**, a leakage-aware multi-dataset framework for explainable credit default prediction. Three public Kaggle credit-risk datasets are standardized into a common schema, merged, cleaned, and evaluated using a reproducible machine-learning pipeline. SMOTE is applied only to training data to avoid test-set leakage. Multiple classifiers are compared using accuracy, balanced accuracy, precision, recall, F1-score, Matthews correlation coefficient (MCC), ROC-AUC, PR-AUC, false-positive rate (FPR), and false-negative rate (FNR). In addition, permutation feature importance is used to explain which borrower and loan attributes contribute most to default prediction.

The main contributions of this paper are as follows:

1. A reproducible multi-dataset credit-risk framework is proposed by integrating three public credit-related datasets into a unified structure.
2. A leakage-aware preprocessing pipeline is applied, including duplicate removal, source exclusion, imputation, encoding, scaling, and training-only SMOTE balancing.
3. Six machine-learning models are compared under both stratified-random validation and leave-one-dataset-out validation.
4. Real experimental results are reported from a reproducible Python pipeline, with Random Forest achieving the strongest stratified-random performance.
5. Explainability analysis is included using permutation importance to identify the most influential predictors of credit default.

The remainder of this paper is organized as follows. Section 2 reviews related work on machine learning and explainable credit-risk prediction. Section 3 presents the proposed CreditFusion-XAI framework. Section 4 describes the experimental setup and datasets. Section 5 reports and discusses the results. Section 6 presents limitations and future work. Section 7 concludes the paper.

## 2 Related Work

Machine learning has become widely used in credit-risk prediction because of its ability to model nonlinear borrower behavior and improve default classification. Earlier credit-scoring methods relied mainly on statistical models such as Logistic Regression and discriminant analysis. These approaches remain useful because they are interpretable and computationally efficient, but they may struggle to capture nonlinear interactions among borrower income, loan amount, interest rate, employment length, and previous default history [6].

Recent credit-risk studies emphasize ensemble learning and explainability. Aruleba and Sun developed an ensemble-based credit-risk prediction approach with model explanation and showed the value of combining predictive accuracy with interpretability [2]. Emmanuel et al. proposed a stacked classifier with feature selection for credit-risk prediction and demonstrated strong performance across multiple credit datasets [3]. Chang et al. investigated explainable machine learning for bank credit worthiness and highlighted the importance of interpretable borrower and repayment variables [4].

Class imbalance is a central challenge in credit default prediction. In most lending datasets, non-default borrowers form the majority class, while default borrowers are less frequent. If this imbalance is not handled properly, a model may achieve high accuracy while failing to identify high-risk borrowers. SMOTE remains a widely used method for generating synthetic minority examples, but it must be applied only to the training set to prevent leakage [7].

Ensemble methods such as Random Forest and boosting-based models are strong choices for structured financial data. Random Forest uses multiple decision trees and aggregates their predictions, reducing variance and improving robustness [8]. XGBoost and related boosting methods sequentially improve weak learners and have been widely used in tabular prediction tasks [9]. In this study, these models are compared with simpler baselines to assess whether preprocessing and validation design improve credit-risk reliability.

Explainability has become an important part of machine-learning evaluation. Lundberg and Lee introduced SHAP as a unified approach to explain model predictions [10]. In applied contexts, explainability has been used to improve transparency in predictive systems. For example, Chen et al. combined advanced machine-learning models with explainable AI for reliable construction-cost prediction, showing that predictive accuracy and interpretability should be considered together [11].

Recent works from the Jordan-related research list also demonstrate the broad use of feature selection, machine learning, and explainable modeling across domains. El-Kenawy et al. used feature selection and machine-learning models for student-performance prediction [12]. A related study applied machine learning for smart-grid stability prediction in energy management [13]. Elkanzi et al. investigated electric-vehicle workplace charging patterns using feature selection and machine learning [14]. Ibrahim et al. proposed cybersecurity threat detection using Waterwheel Plant Optimization and feature selection [15]. Ahsan et al. presented a code-driven process-integration model for environmental sustainability in the petrochemical industry [16]. These studies support the broader methodological value of feature selection, robust validation, and interpretable data-driven modeling.

The user-provided research statement also includes several related works that support the methodological foundation of this paper. Examples include machine-learning applications in heart disease prediction, network anomaly detection, malicious URL prediction, open-source data-mining tool comparison, and machine-intelligence-based opinion mining [17-21]. Although these studies belong to different domains, they demonstrate the relevance of machine-learning pipelines, classification metrics, and data-driven decision support to applied artificial intelligence research.

Despite progress in credit-risk prediction, several gaps remain. Many studies rely on one dataset, which limits external validity. Others report only accuracy, which is not sufficient for imbalanced default prediction. Some works also apply preprocessing or balancing without clearly separating training and testing stages. The proposed CreditFusion-XAI framework addresses these gaps by combining multi-dataset integration, training-only SMOTE balancing, cross-dataset validation, and explainability analysis.

## 3 Proposed CreditFusion-XAI Framework

The proposed CreditFusion-XAI framework consists of five stages: dataset acquisition, schema standardization, leakage-aware preprocessing, machine-learning model training, and explainability-based interpretation. Fig. 1 summarizes the complete workflow.

![Overall architecture of the proposed CreditFusion-XAI framework.](figures/Fig1_CreditFusion_XAI_Framework.png){width=95%}

In the first stage, three publicly available Kaggle credit-risk datasets are downloaded and loaded into the experimental environment. Each dataset contains borrower and loan-related attributes, but the column names and structures differ. Therefore, the second stage standardizes the datasets into a unified schema containing common variables such as age, annual income, employment length, home ownership, loan purpose, loan amount, interest rate, loan-percent-income ratio, credit-history length, previous default status, and the target default label.

Let the merged dataset be defined as:

$$
D = \{(x_i,y_i)\}_{i=1}^{N} \quad (1)
$$

where x_i represents the feature vector of borrower i, and y_i ∈ {0,1} represents the target class. The target label is defined as:

$$
y_i = \begin{cases}1, & \text{default or high-risk loan},\\0, & \text{non-default or fully paid loan}.\end{cases} \quad (2)
$$

The goal is to learn a prediction function:

$$
f_{\theta}: X \rightarrow Y \quad (3)
$$

where f_theta maps borrower and loan features to a predicted default label. The predicted probability of default is expressed as:

$$
p_i = P(y_i=1\mid x_i;\theta) \quad (4)
$$

The final class prediction is obtained using a decision threshold tau:

$$
\hat{y}_i = \begin{cases}1, & p_i \geq \tau,\\0, & p_i < \tau.\end{cases} \quad (5)
$$

In the preprocessing stage, duplicate records are removed and the source-dataset column is excluded from model training to avoid dataset-identity leakage. Missing numerical values are imputed using the median, while missing categorical values are imputed using the most frequent category. Numerical features are standardized as:

$$
x'_{ij} = \frac{x_{ij}-\mu_j}{\sigma_j} \quad (6)
$$

where x_ij is the original value of feature j for sample i, mu_j is the training-set mean, and sigma_j is the training-set standard deviation.

Categorical variables are converted into numerical form using one-hot encoding. To address class imbalance, SMOTE is applied only to the training subset. A synthetic minority sample can be expressed as:

$$
x_{new} = x_i + \lambda(x_{nn}-x_i), \quad \lambda\in[0,1] \quad (7)
$$

where x_i is a minority sample and x_nn is one of its nearest minority-class neighbors.

The Random Forest prediction is based on majority voting across T decision trees:

$$
\hat{y}=\operatorname{mode}\{h_1(x),h_2(x),\ldots,h_T(x)\} \quad (8)
$$

For model explainability, permutation importance is computed by measuring the decrease in predictive performance after permuting a feature:

$$
I_j = S(f,X,y) - S(f,X_{\pi(j)},y) \quad (9)
$$

where S is the F1-score, X_perm(j) is the input matrix after randomly permuting feature j, and I_j is the importance score of feature j.

## 4 Experimental Setup

### 4.1 Datasets

The experiments were conducted using three publicly available credit-risk datasets obtained from Kaggle. The first dataset, **Bank Loan Data**, contains 45,000 loan-applicant records with demographic, financial, and loan-related variables [22]. The second dataset, **Credit Risk Dataset**, contains simulated credit-bureau-style variables for credit-risk modeling [23]. The third dataset, **Credit Risk Analysis**, provides a simplified credit-risk dataset for machine-learning and predictive modeling [24].

For reproducibility and computational efficiency, the experimental run used 30,000 records from each dataset. Therefore, the initial loaded sample contained 90,000 records. After schema standardization and duplicate removal, the final merged dataset contained 89,716 records. Table 1 summarizes the datasets used in the experiment.

**Table 1. Dataset summary after standardization.**

| Dataset              | Kaggle Source                    | Loaded Records   | Standardized Records   |   Standardized Columns |   Default Rate |
|:---------------------|:---------------------------------|:-----------------|:-----------------------|-----------------------:|---------------:|
| Bank Loan Data       | udaymalviya/bank-loan-data       | 30,000           | 30,000                 |                     13 |         0.2223 |
| Credit Risk Dataset  | laotse/credit-risk-dataset       | 30,000           | 30,000                 |                     13 |         0.2182 |
| Credit Risk Analysis | nanditapore/credit-risk-analysis | 30,000           | 30,000                 |                     12 |         0.2182 |

### 4.2 Data Standardization and Integration

Because the three datasets used different column names and structures, a schema-harmonization process was applied before model training. Common variables were mapped to unified names, including age, annual income, employment length, home ownership, loan purpose, loan amount, loan interest rate, loan-percent-income ratio, credit-history length, previous default status, and the target default label. The source-dataset variable was retained only for leave-one-dataset-out validation and was excluded from model features to avoid leakage.

### 4.3 Preprocessing Pipeline

The preprocessing pipeline was designed to avoid data leakage. Missing numerical values were imputed using the median of the training set, while missing categorical values were imputed using the most frequent value. Numerical features were standardized, and categorical features were transformed using one-hot encoding. Class imbalance was handled using SMOTE applied only to the training set inside the pipeline. This prevents synthetic samples or minority-class information from influencing the test data.

### 4.4 Validation Strategy

Two validation strategies were used. The first was a stratified-random split, where 80% of the merged data were used for training and 20% were used for testing. This split preserved the default/non-default class distribution. The stratified-random experiment used 71,772 training samples and 17,944 testing samples.

The second was leave-one-dataset-out validation. In this setting, two datasets were used for training, and the remaining dataset was held out completely for testing. This validation is stricter because it evaluates whether the model can generalize to a dataset source not seen during training:

$$
D_{train}=\bigcup_{s\neq h}D_s,\quad D_{test}=D_h \quad (10)
$$

where D_h is the held-out dataset and s denotes the dataset source.

### 4.5 Models and Evaluation Metrics

Six classification models were evaluated: Logistic Regression, Decision Tree, Random Forest, HistGradientBoosting, XGBoost, and K-Nearest Neighbors. Random Forest and boosting-based models were included because ensemble methods are usually effective on structured tabular financial data. Logistic Regression was included as an interpretable linear baseline, KNN as a distance-based non-parametric baseline, and Decision Tree as a simple rule-based classifier.

The models were evaluated using accuracy, balanced accuracy, precision, recall, F1-score, MCC, FPR, FNR, ROC-AUC, and PR-AUC. ROC analysis is a standard threshold-independent tool for classifier assessment [25]. Precision and recall are defined as:

$$
\text{Precision}=\frac{TP}{TP+FP},\qquad \text{Recall}=\frac{TP}{TP+FN} \quad (11)
$$

The F1-score balances precision and recall:

$$
F_1=2\times\frac{\text{Precision}\times\text{Recall}}{\text{Precision}+\text{Recall}} \quad (12)
$$

MCC is used because it provides a balanced assessment under class imbalance:

$$
\text{MCC}=\frac{TP\times TN-FP\times FN}{\sqrt{(TP+FP)(TP+FN)(TN+FP)(TN+FN)}} \quad (13)
$$

The false-positive and false-negative rates are:

$$
\text{FPR}=\frac{FP}{FP+TN},\qquad \text{FNR}=\frac{FN}{FN+TP} \quad (14)
$$

## 5 Results and Discussion

### 5.1 Stratified-Random Validation Results

Table 2 presents the results obtained using the stratified-random split. Under this setting, Random Forest achieved the best overall performance, with 93.16% accuracy, 88.87% balanced accuracy, 86.85% precision, 81.20% recall, 83.93% F1-score, 79.67% MCC, 97.14% ROC-AUC, and 93.02% PR-AUC.

**Table 2. Stratified-random validation results.**

| Model                |   Accuracy |   Balanced Acc. |   Precision |   Recall |     F1 |    MCC |    FPR |    FNR |   ROC-AUC |   PR-AUC |
|:---------------------|-----------:|----------------:|------------:|---------:|-------:|-------:|-------:|-------:|----------:|---------:|
| Logistic Regression  |     0.812  |          0.8164 |      0.5483 |   0.8241 | 0.6585 | 0.5571 | 0.1914 | 0.1759 |    0.8985 |   0.7514 |
| Decision Tree        |     0.8995 |          0.8587 |      0.7638 |   0.7859 | 0.7747 | 0.7101 | 0.0685 | 0.2141 |    0.931  |   0.8628 |
| Random Forest        |     0.9316 |          0.8887 |      0.8685 |   0.812  | 0.8393 | 0.7967 | 0.0346 | 0.188  |    0.9714 |   0.9302 |
| HistGradientBoosting |     0.9289 |          0.8677 |      0.9026 |   0.7585 | 0.8243 | 0.7848 | 0.0231 | 0.2415 |    0.9559 |   0.9076 |
| XGBoost              |     0.9213 |          0.8633 |      0.8657 |   0.7598 | 0.8093 | 0.7625 | 0.0332 | 0.2402 |    0.9476 |   0.8947 |
| KNN                  |     0.8328 |          0.8318 |      0.5843 |   0.8302 | 0.6859 | 0.5931 | 0.1665 | 0.1698 |    0.9066 |   0.7458 |

The results show that ensemble models outperformed simpler classifiers. Random Forest achieved the highest F1-score and MCC, indicating the strongest balance between identifying default cases and avoiding false predictions. HistGradientBoosting achieved the highest precision and the lowest false-positive rate, meaning that it was more conservative when predicting default. However, its recall was lower than Random Forest, which means it missed more true default cases.

Logistic Regression achieved high recall but lower precision, indicating that it detected many default cases but produced more false alarms. KNN also achieved high recall but had weaker precision and overall performance. These findings confirm that accuracy alone is not enough in credit-risk prediction; a model must balance recall, precision, and false-alarm behavior.

![Comparison of the main stratified-random validation metrics across the evaluated models.](figures/Fig2_Stratified_Model_Comparison.png){width=95%}

### 5.2 Cross-Dataset Robustness Analysis

To evaluate generalization ability, leave-one-dataset-out validation was applied. In this setting, two datasets were used for model training, while the remaining dataset was held out completely for testing. This strategy is stricter than a stratified-random split because it evaluates whether the learned model can generalize to a new data source rather than only to unseen samples from the same merged distribution.

**Table 3. Best-performing models under stratified-random and leave-one-dataset-out validation.**

| Validation Setting                          | Model                | Train   | Test   |   Accuracy |   Balanced Acc. |   Precision |   Recall |     F1 |    MCC |   ROC-AUC |   PR-AUC |
|:--------------------------------------------|:---------------------|:--------|:-------|-----------:|----------------:|------------:|---------:|-------:|-------:|----------:|---------:|
| Leave-one-dataset-out: Bank Loan Data       | Random Forest        | 59,716  | 30,000 |     0.8722 |          0.7513 |      0.831  |   0.5336 | 0.6499 | 0.5973 |    0.8841 |   0.7715 |
| Leave-one-dataset-out: Bank Loan Data       | Logistic Regression  | 59,716  | 30,000 |     0.8114 |          0.7712 |      0.561  |   0.6988 | 0.6223 | 0.504  |    0.8551 |   0.6869 |
| Leave-one-dataset-out: Bank Loan Data       | XGBoost              | 59,716  | 30,000 |     0.8654 |          0.7314 |      0.8373 |   0.49   | 0.6182 | 0.572  |    0.8682 |   0.7456 |
| Leave-one-dataset-out: Credit Risk Analysis | Random Forest        | 59,858  | 29,858 |     0.9339 |          0.8678 |      0.9344 |   0.7503 | 0.8323 | 0.7991 |    0.9682 |   0.926  |
| Leave-one-dataset-out: Credit Risk Analysis | HistGradientBoosting | 59,858  | 29,858 |     0.917  |          0.848  |      0.8736 |   0.7254 | 0.7926 | 0.7463 |    0.9401 |   0.8816 |
| Leave-one-dataset-out: Credit Risk Analysis | XGBoost              | 59,858  | 29,858 |     0.91   |          0.8262 |      0.8842 |   0.6773 | 0.767  | 0.7222 |    0.9222 |   0.8554 |
| Leave-one-dataset-out: Credit Risk Dataset  | Random Forest        | 59,858  | 29,858 |     0.9841 |          0.9696 |      0.9829 |   0.9438 | 0.963  | 0.9532 |    0.9992 |   0.9972 |
| Leave-one-dataset-out: Credit Risk Dataset  | HistGradientBoosting | 59,858  | 29,858 |     0.928  |          0.8519 |      0.9397 |   0.7166 | 0.8132 | 0.7804 |    0.948  |   0.897  |
| Leave-one-dataset-out: Credit Risk Dataset  | Decision Tree        | 59,858  | 29,858 |     0.9205 |          0.8558 |      0.8764 |   0.7408 | 0.803  | 0.7578 |    0.9307 |   0.8716 |
| Stratified random split                     | Random Forest        | 71,772  | 17,944 |     0.9316 |          0.8887 |      0.8685 |   0.812  | 0.8393 | 0.7967 |    0.9714 |   0.9302 |
| Stratified random split                     | HistGradientBoosting | 71,772  | 17,944 |     0.9289 |          0.8677 |      0.9026 |   0.7585 | 0.8243 | 0.7848 |    0.9559 |   0.9076 |
| Stratified random split                     | XGBoost              | 71,772  | 17,944 |     0.9213 |          0.8633 |      0.8657 |   0.7598 | 0.8093 | 0.7625 |    0.9476 |   0.8947 |

The results in Table 3 show that Random Forest was the most stable model across validation settings. Under the stratified-random split, Random Forest achieved the best overall performance, with an accuracy of 0.9316, F1-score of 0.8393, MCC of 0.7967, ROC-AUC of 0.9714, and PR-AUC of 0.9302. This confirms that Random Forest captured nonlinear borrower-risk patterns more effectively than the other evaluated models.

In the leave-one-dataset-out experiment, Random Forest achieved the strongest F1-score for each held-out dataset. When Bank Loan Data was held out, Random Forest achieved an accuracy of 0.8722 and F1-score of 0.6499. This was the most difficult validation case, as shown by the relatively low recall of 0.5336 and high false-negative rate of 0.4664. This suggests that Bank Loan Data contains distributional patterns that are less similar to the other two datasets.

When Credit Risk Analysis was held out, Random Forest achieved stronger generalization, with 0.9339 accuracy, 0.8323 F1-score, and 0.9682 ROC-AUC. The best cross-dataset performance appeared when Credit Risk Dataset was held out, where Random Forest achieved 0.9841 accuracy, 0.9630 F1-score, 0.9532 MCC, 0.9992 ROC-AUC, and 0.9972 PR-AUC. This indicates that the training data from the other two datasets provided patterns that generalized well to this held-out dataset.

![Cross-dataset robustness of Random Forest under stratified-random and leave-one-dataset-out validation.](figures/Fig3_Cross_Dataset_Robustness.png){width=85%}

### 5.3 Explainability Analysis

To improve model transparency, permutation feature importance was computed for the best-performing model under the stratified-random validation setting. This method estimates the contribution of each feature by measuring the decrease in F1-score after randomly permuting the feature values. A larger decrease indicates that the feature has a stronger influence on model prediction.

![Permutation feature importance of the best-performing model. Importance is measured as the mean decrease in F1-score after permuting each feature.](figures/Fig4_Permutation_Feature_Importance.png){width=85%}

**Table 4. Permutation feature importance of the best model.**

|   Rank | Feature             |   Importance Mean |   Importance SD |
|-------:|:--------------------|------------------:|----------------:|
|      1 | previous_default    |            0.2693 |          0.0047 |
|      2 | loan_int_rate       |            0.261  |          0.0064 |
|      3 | loan_percent_income |            0.2568 |          0.0083 |
|      4 | home_ownership      |            0.1997 |          0.0082 |
|      5 | purpose             |            0.1744 |          0.0058 |
|      6 | annual_income       |            0.1588 |          0.0051 |
|      7 | emp_length          |            0.0762 |          0.0013 |
|      8 | loan_amount         |            0.0632 |          0.0027 |
|      9 | cred_length         |            0.0571 |          0.0029 |
|     10 | age                 |            0.0545 |          0.0031 |
|     11 | credit_score        |            0.0208 |          0.0013 |
|     12 | loan_grade          |            0      |          0      |

The explainability results show that previous default history was the most influential feature, with an importance score of 0.2693. This is financially meaningful because previous default behavior is a direct indicator of repayment risk. The second and third most important features were loan interest rate and loan-percent-income ratio, with importance scores of 0.2610 and 0.2568, respectively. These variables reflect the cost of borrowing and the borrower repayment burden relative to income.

Home ownership and loan purpose also showed strong importance scores of 0.1997 and 0.1744, respectively. These features may capture borrower stability and the financial motivation behind the loan. Annual income was also important, with an importance score of 0.1588, confirming that repayment capacity remains a key factor in credit default prediction.

### 5.4 Correlation Analysis

A correlation heatmap was generated to examine the relationships among the numerical features in the merged dataset. The strongest positive correlation appeared between age and credit-history length, with a correlation coefficient of 0.88. This is expected because older borrowers usually have longer credit histories. Employment length also showed moderate positive correlations with age and credit-history length, with coefficients of 0.48 and 0.42, respectively.

![Correlation heatmap of numerical credit-risk features.](figures/Fig5_Correlation_Heatmap.png){width=85%}

A moderate positive correlation was also found between loan amount and loan-percent-income ratio, with a coefficient of 0.57. This indicates that larger loans tend to represent a higher proportion of borrower income. Annual income had a negative correlation with loan-percent-income ratio, with a coefficient of -0.24, which is also expected because higher-income borrowers may carry a lower loan burden relative to income. These correlations support the financial validity of the integrated dataset and show that the selected features contain meaningful relationships rather than random noise.

### 5.5 Discussion

The experimental results demonstrate that the proposed CreditFusion-XAI framework improves the reliability of credit default prediction by combining multi-dataset integration, leakage-aware preprocessing, training-only SMOTE, model comparison, cross-dataset validation, and explainability analysis. The strongest model in the stratified-random validation was Random Forest, which achieved 93.16% accuracy, 83.93% F1-score, 79.67% MCC, 97.14% ROC-AUC, and 93.02% PR-AUC.

HistGradientBoosting achieved the highest precision and lowest false-positive rate in the stratified-random setting. This means it was more conservative when classifying applicants as risky. In practical lending, such a model may be useful when the institution wants to avoid rejecting reliable borrowers. However, Random Forest achieved higher recall and F1-score, making it more balanced for identifying risky borrowers.

The leave-one-dataset-out experiment showed that model performance changed depending on the held-out dataset. This finding is important because it proves that random-split evaluation alone is not enough. A credit-risk model may perform strongly when training and testing records come from the same merged distribution but may lose performance when tested on a completely unseen dataset source. Therefore, cross-dataset validation should be included in credit-risk studies whenever multiple data sources are available.

The explainability results confirm that the model relied on financially interpretable predictors. Previous default history, loan interest rate, loan-percent-income ratio, home ownership, loan purpose, and annual income were the most influential features. These factors are consistent with practical lending logic and support the trustworthiness of the proposed framework.

## 6 Limitations and Future Work

Although the proposed framework provides a stronger evaluation than the original version of the manuscript, several limitations remain. First, the current experiment used a reproducible sample of 30,000 records from each dataset rather than the full available data. This was done to reduce runtime in Google Colab. Before journal-level extension, the experiment can be rerun using the full datasets by setting `MAX_ROWS_PER_DATASET = None` in the public code.

Second, the datasets were obtained from public Kaggle sources. Although they are useful for reproducible research, they may not fully represent real bank portfolios, local lending regulations, or institution-specific risk policies. Future work should validate the framework on real institutional credit data if available.

Third, the study focuses on binary default prediction. In real financial systems, risk may be better represented using multiple risk levels, such as low, medium, and high risk. Future studies can extend the framework to multiclass credit-risk grading.

Fourth, the explainability analysis used permutation importance. Although this provides useful global interpretation, future work can add SHAP and LIME to provide both global and local explanations for individual applicants.

Finally, fairness and bias analysis were not included in the current experiment. Future versions should evaluate whether the model produces biased decisions across demographic or socioeconomic groups, especially if sensitive variables are available.

## 7 Conclusion

This paper presented CreditFusion-XAI, a leakage-aware multi-dataset framework for explainable credit default prediction. Three public Kaggle credit-risk datasets were standardized, merged, cleaned, and evaluated using a reproducible machine-learning pipeline. The framework applied missing-value imputation, categorical encoding, feature scaling, duplicate removal, and SMOTE balancing applied only to the training data.

Six machine-learning models were evaluated under stratified-random and leave-one-dataset-out validation settings. The best stratified-random result was achieved by Random Forest, with 93.16% accuracy, 83.93% F1-score, 79.67% MCC, 97.14% ROC-AUC, and 93.02% PR-AUC. The leave-one-dataset-out experiment showed that Random Forest also provided the strongest cross-dataset performance, although performance varied across held-out datasets.

Explainability analysis showed that previous default history, loan interest rate, loan-percent-income ratio, home ownership, loan purpose, and annual income were the most influential predictors. These findings are consistent with financial risk logic and improve trust in the proposed framework.

Overall, the results demonstrate that robust preprocessing, multi-dataset validation, and explainability are essential for reliable credit default prediction. The proposed framework is suitable for ITAF 2026 as an applied artificial intelligence and data-driven financial risk management study.

## Declarations

**Data Availability.** The datasets used in this study are publicly available from Kaggle: Bank Loan Data at https://www.kaggle.com/datasets/udaymalviya/bank-loan-data, Credit Risk Dataset at https://www.kaggle.com/datasets/laotse/credit-risk-dataset, and Credit Risk Analysis at https://www.kaggle.com/datasets/nanditapore/credit-risk-analysis. The experimental run used 30,000 records from each dataset for reproducibility and computational efficiency.

**Code Availability.** The complete Python/Colab implementation used to generate the experimental results, tables, and figures is available at https://colab.research.google.com/drive/1RdsTaAeNvkFwJ-QO6bbPrhC8gb-zgVOR. The code will also be released in a public GitHub repository named `CreditFusion-XAI`; the final repository URL should be inserted before submission.

**Conflict of Interest.** The authors declare that they have no conflict of interest.

**Funding.** No external funding was received for this study.

**Ethical Approval.** This study uses publicly available anonymized credit-risk datasets and does not involve human participants, animals, or private personal data.

**Author Contributions.** Shimaa M. Abd-Elsalam contributed to conceptualization, manuscript preparation, methodology design, literature review, and interpretation of the credit-risk prediction results. Hosam Eldin Fawzan Sayed contributed to experimental design, Python implementation, model validation, result analysis, reproducibility preparation, and final manuscript revision. Both authors reviewed and approved the final version of the manuscript.

## References

[1] Bouri, E., Jain, A., Roubaud, D.: Credit risk, financial crises, and economic uncertainty: Evidence from global data. Finance Research Letters 42, 101925 (2021).

[2] Aruleba, I.T., Sun, Y.: Effective credit risk prediction using ensemble classifiers with model explanation. IEEE Access 12, 118292-118307 (2024). https://doi.org/10.1109/ACCESS.2024.3445308

[3] Emmanuel, I., Sun, Y., Wang, Z.: A machine learning-based credit risk prediction engine system using a stacked classifier and a filter-based feature selection method. Journal of Big Data 11, 23 (2024). https://doi.org/10.1186/s40537-024-00882-0

[4] Chang, V., Xu, Q.A., Akinloye, S.H., et al.: Prediction of bank credit worthiness through credit risk analysis: an explainable machine learning study. Annals of Operations Research (2024). https://doi.org/10.1007/s10479-024-06134-x

[5] Shreya, Pathak, H.: Explainable artificial intelligence credit risk assessment using machine learning. arXiv preprint arXiv:2506.19383 (2025).

[6] Bulut, C., Arslan, E.: Comparison of the impact of dimensionality reduction and data splitting on classification performance in credit risk assessment. Artificial Intelligence Review 57, 252 (2024). https://doi.org/10.1007/s10462-024-10904-1

[7] Chawla, N.V., Bowyer, K.W., Hall, L.O., Kegelmeyer, W.P.: SMOTE: Synthetic Minority Over-sampling Technique. Journal of Artificial Intelligence Research 16, 321-357 (2002). https://doi.org/10.1613/jair.953

[8] Breiman, L.: Random forests. Machine Learning 45, 5-32 (2001). https://doi.org/10.1023/A:1010933404324

[9] Chen, T., Guestrin, C.: XGBoost: A scalable tree boosting system. In: Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining, pp. 785-794 (2016). https://doi.org/10.1145/2939672.2939785

[10] Lundberg, S.M., Lee, S.-I.: A unified approach to interpreting model predictions. In: Advances in Neural Information Processing Systems, pp. 4765-4774 (2017).

[11] Chen, L., Xu, C., Lim, W.H., Sharma, A., Tiang, S.S., Chong, K.S., El-Kenawy, E.-S.M., Alhussan, A.A., Eid, M.M., Khafaga, D.S.: Transparent and reliable construction cost prediction using advanced machine learning and explainable AI. Engineering Science and Technology, an International Journal 70, 102159 (2025). https://doi.org/10.1016/j.jestch.2025.102159

[12] El-Kenawy, E.-S.M., Alharbi, A.H., Alhussan, A., Eid, M.M., Sobhi, M., Khafaga, D.S.: Optimizing student performance prediction through feature selection and machine learning models. In: 2025 International Telecommunications Conference (ITC-Egypt), pp. 226-231 (2025). https://doi.org/10.1109/ITC-Egypt66095.2025.11186576

[13] El-Kenawy, E.-S.M., Alharbi, A.H., Alhussan, A.A., Eid, M.M., Sobhi, M., Khafaga, D.S.: Machine learning-based prediction of smart grid stability for enhanced energy management. In: 2025 International Telecommunications Conference (ITC-Egypt), pp. 232-237 (2025). https://doi.org/10.1109/ITC-Egypt66095.2025.11186587

[14] Elkanzi, M., El-Kenawy, E.-S.M., Alhussan, A., Eid, M.M., Khafaga, D.S., Takieldeen, A.E.: Optimizing electric vehicle workplace charging patterns using feature selection and machine learning models. In: 2025 International Telecommunications Conference (ITC-Egypt) (2025). https://doi.org/10.1109/ITC-Egypt66095.2025.11186613

[15] Ibrahim, A., El-Kenawy, E.-S.M., Alhussan, A., Takieldeen, A.E., Gaber, K.: Cybersecurity threat detection and feature selection using Waterwheel Plant Optimization. In: 2025 International Telecommunications Conference (ITC-Egypt) (2025). https://doi.org/10.1109/ITC-Egypt66095.2025.11186684

[16] Ahsan, M., Tian, L., Du, R., Alhussan, A.A., El-Kenawy, E.-S.M.: Enhancing environmental sustainability through code-driven process integration in the petrochemical industry. Frontiers in Environmental Science 12, 1389639 (2024). https://doi.org/10.3389/fenvs.2024.1389639

[17] Elbehiery, H.M., et al.: Improving heart disease prediction accuracy through machine learning algorithms. Statistics, Optimization and Information Computing 14(2), 736-755 (2025).

[18] Al-Khazraji, H.S., et al.: Machine learning models with neutrosophic numbers for network anomaly detection and security defense technology. Neutrosophic Sets and Systems 83, 50-64 (2025).

[19] Eassa, M.A., Abdelhafeez, A., Metwaly, A.A., Salama, A.S.: Efficient machine learning for prediction of malicious URLs under neutrosophic uncertainty framework. Neutrosophic Sets and Systems 83, 456-468 (2025).

[20] Ibrahim, A.A.E., Hashad, A.I., Shawky, N.E.M.: A comparison of open-source data mining tools for breast cancer classification. In: Handbook of Research on Machine Learning Innovations and Trends, pp. 636-651 (2023).

[21] Abdelhafeez, A., Aziz, A., Khalil, N.: Building a sustainable social feedback loop: a machine intelligence approach for Twitter opinion mining. Sustainable Machine Intelligence Journal 1(6), 1-12 (2022).

[22] Malviya, U.: Bank Loan Data. Kaggle Dataset. https://www.kaggle.com/datasets/udaymalviya/bank-loan-data

[23] Lao Tse: Credit Risk Dataset. Kaggle Dataset. https://www.kaggle.com/datasets/laotse/credit-risk-dataset

[24] Pore, N.: Credit Risk Analysis. Kaggle Dataset. https://www.kaggle.com/datasets/nanditapore/credit-risk-analysis

[25] Fawcett, T.: An introduction to ROC analysis. Pattern Recognition Letters 27(8), 861-874 (2006). https://doi.org/10.1016/j.patrec.2005.10.010
