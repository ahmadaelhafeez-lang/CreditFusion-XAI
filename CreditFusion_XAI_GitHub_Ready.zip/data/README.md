# Data

The datasets are not redistributed in this repository. They are downloaded from Kaggle by the main script.

Dataset links:
- https://www.kaggle.com/datasets/udaymalviya/bank-loan-data
- https://www.kaggle.com/datasets/laotse/credit-risk-dataset
- https://www.kaggle.com/datasets/nanditapore/credit-risk-analysis
