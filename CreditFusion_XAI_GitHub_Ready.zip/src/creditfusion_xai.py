#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CreditFusion-XAI
Leakage-aware multi-dataset credit default prediction using machine learning.

This script reproduces the experiments reported in:
"CreditFusion-XAI: A Leakage-Aware Multi-Dataset Framework for Explainable Credit Default Prediction"

Main functions:
1. Download three public Kaggle credit-risk datasets.
2. Standardize heterogeneous column names into a unified schema.
3. Merge datasets and remove duplicate records.
4. Exclude source_dataset from model features to reduce dataset-identity leakage.
5. Apply imputation, scaling, one-hot encoding, and training-only SMOTE.
6. Train six classifiers:
   Logistic Regression, Decision Tree, Random Forest, HistGradientBoosting, XGBoost, and KNN.
7. Evaluate with stratified-random and leave-one-dataset-out validation.
8. Generate CSV result tables and publication-ready figures.
9. Generate permutation feature importance for the best stratified-random model.

Dataset links:
- https://www.kaggle.com/datasets/udaymalviya/bank-loan-data
- https://www.kaggle.com/datasets/laotse/credit-risk-dataset
- https://www.kaggle.com/datasets/nanditapore/credit-risk-analysis
"""

from __future__ import annotations

import argparse
import glob
import os
import random
import re
import shutil
import subprocess
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline

from xgboost import XGBClassifier

import matplotlib.pyplot as plt


DATASETS: Dict[str, str] = {
    "bank_loan_data": "udaymalviya/bank-loan-data",
    "credit_risk_dataset": "laotse/credit-risk-dataset",
    "credit_risk_analysis": "nanditapore/credit-risk-analysis",
}


@dataclass
class ExperimentConfig:
    output_dir: Path
    max_rows_per_dataset: Optional[int]
    test_size: float
    seed: int
    n_repeats_importance: int
    importance_sample_size: int


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)


def clean_column_name(col: str) -> str:
    col = str(col).strip()
    col = col.replace("-", "_").replace(" ", "_")
    col = re.sub(r"[^A-Za-z0-9_]+", "", col)
    col = re.sub(r"_+", "_", col)
    return col.lower()


def download_dataset(slug: str, local_name: str, download_root: Path) -> Path:
    """
    Download a Kaggle dataset.

    Priority:
    1. kagglehub.dataset_download
    2. Kaggle CLI, requiring ~/.kaggle/kaggle.json

    For GitHub/Colab use:
    - Add kaggle.json to ~/.kaggle/kaggle.json
    - chmod 600 ~/.kaggle/kaggle.json
    """
    try:
        import kagglehub  # type: ignore

        path = kagglehub.dataset_download(slug)
        print(f"[OK] Downloaded {local_name} using kagglehub: {path}")
        return Path(path)
    except Exception as exc:
        print(f"[WARN] kagglehub failed for {local_name}: {exc}")

    local_dir = download_root / local_name
    local_dir.mkdir(parents=True, exist_ok=True)

    print(f"[INFO] Trying Kaggle CLI for {local_name}")
    subprocess.check_call(
        ["kaggle", "datasets", "download", "-d", slug, "-p", str(local_dir)]
    )

    for zip_path in local_dir.glob("*.zip"):
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(local_dir)

    print(f"[OK] Downloaded {local_name} using Kaggle CLI: {local_dir}")
    return local_dir


def find_largest_csv(folder: Path) -> Path:
    csv_files = glob.glob(str(folder / "**" / "*.csv"), recursive=True)
    if not csv_files:
        raise FileNotFoundError(f"No CSV files were found in {folder}")

    return Path(max(csv_files, key=os.path.getsize))


def standardize_credit_dataframe(df: pd.DataFrame, source_name: str) -> pd.DataFrame:
    """
    Convert different credit-risk dataset schemas into one unified structure.

    Target:
    - default = 1 means default/high-risk/not fully paid.
    - default = 0 means non-default/fully paid.
    """
    df = df.copy()
    df.columns = [clean_column_name(c) for c in df.columns]

    rename_map = {
        "person_age": "age",
        "age": "age",
        "person_income": "annual_income",
        "income": "annual_income",
        "person_emp_length": "emp_length",
        "person_emp_exp": "emp_length",
        "emp_length": "emp_length",
        "person_home_ownership": "home_ownership",
        "home": "home_ownership",
        "home_ownership": "home_ownership",
        "loan_intent": "purpose",
        "intent": "purpose",
        "purpose": "purpose",
        "loan_amnt": "loan_amount",
        "amount": "loan_amount",
        "loan_amount": "loan_amount",
        "loan_int_rate": "loan_int_rate",
        "rate": "loan_int_rate",
        "loan_percent_income": "loan_percent_income",
        "percent_income": "loan_percent_income",
        "cb_person_cred_hist_length": "cred_length",
        "cb_preson_cred_hist_length": "cred_length",
        "cred_length": "cred_length",
        "cb_person_default_on_file": "previous_default",
        "previous_loan_defaults_on_file": "previous_default",
        "default": "previous_default",
        "loan_status": "target_status",
        "status": "target_status",
        "credit_score": "credit_score",
        "loan_grade": "loan_grade",
    }

    df = df.rename(columns={c: rename_map.get(c, c) for c in df.columns})

    if "target_status" not in df.columns:
        raise RuntimeError(
            f"Target column was not found in {source_name}. "
            f"Available columns: {df.columns.tolist()}"
        )

    raw_target = df["target_status"]

    if raw_target.dtype == "object":
        text_target = raw_target.astype(str).str.lower().str.strip()
        y = np.where(
            text_target.str.contains("not|default|charged|late|bad|risk|1", regex=True),
            1,
            0,
        )
    else:
        # Common Kaggle credit datasets use 1 = default/risky, 0 = non-default.
        y = raw_target.astype(int).values

    df["default"] = y.astype(int)
    df["source_dataset"] = source_name

    keep_columns = [
        "age",
        "annual_income",
        "home_ownership",
        "emp_length",
        "purpose",
        "loan_amount",
        "loan_int_rate",
        "loan_percent_income",
        "cred_length",
        "previous_default",
        "credit_score",
        "loan_grade",
        "source_dataset",
        "default",
    ]

    available_columns = [c for c in keep_columns if c in df.columns]
    return df[available_columns].copy()


def load_and_merge_datasets(config: ExperimentConfig) -> Tuple[pd.DataFrame, pd.DataFrame]:
    download_root = config.output_dir / "_downloads"
    download_root.mkdir(parents=True, exist_ok=True)

    frames: List[pd.DataFrame] = []
    summary_rows: List[Dict[str, object]] = []

    for dataset_name, dataset_slug in DATASETS.items():
        print("=" * 90)
        print(f"[INFO] Loading {dataset_name}")
        print(f"[INFO] Kaggle slug: {dataset_slug}")

        dataset_folder = download_dataset(dataset_slug, dataset_name, download_root)
        csv_path = find_largest_csv(dataset_folder)

        df_raw = pd.read_csv(csv_path, low_memory=False)

        if config.max_rows_per_dataset is not None and len(df_raw) > config.max_rows_per_dataset:
            df_raw = (
                df_raw.sample(n=config.max_rows_per_dataset, random_state=config.seed)
                .reset_index(drop=True)
            )

        df_std = standardize_credit_dataframe(df_raw, dataset_name)
        frames.append(df_std)

        summary_rows.append(
            {
                "source_dataset": dataset_name,
                "kaggle_slug": dataset_slug,
                "csv_path": str(csv_path),
                "rows_loaded": len(df_raw),
                "rows_standardized": len(df_std),
                "columns_standardized": df_std.shape[1],
                "default_rate": df_std["default"].mean(),
            }
        )

    dataset_summary = pd.DataFrame(summary_rows)
    data = pd.concat(frames, ignore_index=True)

    return data, dataset_summary


def clean_merged_data(data: pd.DataFrame) -> pd.DataFrame:
    data = data.copy()

    numeric_columns = [
        "age",
        "annual_income",
        "emp_length",
        "loan_amount",
        "loan_int_rate",
        "loan_percent_income",
        "cred_length",
        "credit_score",
    ]

    for col in numeric_columns:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col], errors="coerce")
            data.loc[data[col] < 0, col] = np.nan

    if "age" in data.columns:
        data.loc[(data["age"] < 18) | (data["age"] > 100), "age"] = np.nan

    if "loan_percent_income" in data.columns:
        data.loc[data["loan_percent_income"] > 1.5, "loan_percent_income"] = np.nan

    before = len(data)
    data = data.drop_duplicates().reset_index(drop=True)
    after = len(data)

    print(f"[INFO] Rows before duplicate removal: {before}")
    print(f"[INFO] Rows after duplicate removal:  {after}")
    print(f"[INFO] Removed duplicates: {before - after}")

    return data


def make_preprocessor(X_features: pd.DataFrame) -> ColumnTransformer:
    numeric_features = X_features.select_dtypes(include=[np.number]).columns.tolist()
    categorical_features = X_features.select_dtypes(exclude=[np.number]).columns.tolist()

    try:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse=False)

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "num",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="median")),
                        ("scaler", StandardScaler()),
                    ]
                ),
                numeric_features,
            ),
            (
                "cat",
                Pipeline(
                    [
                        ("imputer", SimpleImputer(strategy="most_frequent")),
                        ("onehot", encoder),
                    ]
                ),
                categorical_features,
            ),
        ],
        remainder="drop",
    )

    return preprocessor


def get_models(seed: int) -> Dict[str, object]:
    return {
        "Logistic Regression": LogisticRegression(
            max_iter=2000,
            class_weight="balanced",
            random_state=seed,
        ),
        "Decision Tree": DecisionTreeClassifier(
            max_depth=12,
            class_weight="balanced",
            random_state=seed,
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=250,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        ),
        "HistGradientBoosting": HistGradientBoostingClassifier(
            max_iter=250,
            learning_rate=0.06,
            max_leaf_nodes=31,
            random_state=seed,
        ),
        "XGBoost": XGBClassifier(
            n_estimators=300,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.90,
            colsample_bytree=0.90,
            eval_metric="logloss",
            random_state=seed,
            n_jobs=-1,
        ),
        "KNN": KNeighborsClassifier(n_neighbors=7),
    }


def evaluate_model(
    model_name: str,
    model: object,
    preprocessor: ColumnTransformer,
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: np.ndarray,
    y_test: np.ndarray,
    split_name: str,
    seed: int,
) -> Tuple[Dict[str, object], ImbPipeline]:
    """
    SMOTE is applied only to the training folds inside the pipeline.
    This avoids test-set leakage.
    """
    pipeline = ImbPipeline(
        steps=[
            ("preprocess", preprocessor),
            ("smote", SMOTE(random_state=seed)),
            ("model", model),
        ]
    )

    pipeline.fit(X_train, y_train)
    y_pred = pipeline.predict(X_test)

    try:
        y_prob = pipeline.predict_proba(X_test)[:, 1]
    except Exception:
        y_prob = None

    cm = confusion_matrix(y_test, y_pred)
    if cm.shape == (2, 2):
        tn, fp, fn, tp = cm.ravel()
        fpr = fp / (fp + tn + 1e-12)
        fnr = fn / (fn + tp + 1e-12)
    else:
        tn = fp = fn = tp = np.nan
        fpr = fnr = np.nan

    result: Dict[str, object] = {
        "split": split_name,
        "model": model_name,
        "n_train": len(y_train),
        "n_test": len(y_test),
        "accuracy": accuracy_score(y_test, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_test, y_pred),
        "precision": precision_score(y_test, y_pred, zero_division=0),
        "recall": recall_score(y_test, y_pred, zero_division=0),
        "f1": f1_score(y_test, y_pred, zero_division=0),
        "mcc": matthews_corrcoef(y_test, y_pred),
        "fpr": fpr,
        "fnr": fnr,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "tp": tp,
    }

    if y_prob is not None and len(np.unique(y_test)) == 2:
        result["roc_auc"] = roc_auc_score(y_test, y_prob)
        result["pr_auc"] = average_precision_score(y_test, y_prob)
    else:
        result["roc_auc"] = np.nan
        result["pr_auc"] = np.nan

    return result, pipeline


def plot_stratified_comparison(results_df: pd.DataFrame, output_dir: Path) -> None:
    df = results_df[results_df["split"] == "stratified_random"].copy()
    if df.empty:
        return

    metrics = ["accuracy", "precision", "recall", "f1", "roc_auc", "pr_auc"]
    x = np.arange(len(df["model"]))
    width = 0.12

    plt.figure(figsize=(12, 6))
    for i, metric in enumerate(metrics):
        plt.bar(x + (i - len(metrics) / 2) * width, df[metric], width, label=metric)

    plt.xticks(x, df["model"], rotation=30, ha="right")
    plt.ylabel("Score")
    plt.ylim(0, 1.05)
    plt.legend(ncol=3, fontsize=9)
    plt.tight_layout()
    plt.savefig(output_dir / "Fig2_Stratified_Model_Comparison.png", dpi=300, bbox_inches="tight")
    plt.close()


def plot_cross_dataset_robustness(best_df: pd.DataFrame, output_dir: Path) -> None:
    rf = best_df[best_df["model"] == "Random Forest"].copy()
    if rf.empty:
        return

    labels = (
        rf["split"]
        .str.replace("leave_one_dataset_out_", "", regex=False)
        .str.replace("_", " ")
        .str.replace("stratified random", "stratified random")
    )

    plt.figure(figsize=(9, 5))
    plt.bar(labels, rf["f1"])
    plt.ylabel("F1-score")
    plt.ylim(0, 1.05)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(output_dir / "Fig3_Cross_Dataset_Robustness.png", dpi=300, bbox_inches="tight")
    plt.close()


def plot_feature_importance(importance_df: pd.DataFrame, output_dir: Path) -> None:
    top = importance_df.sort_values("importance_mean", ascending=False).head(12).iloc[::-1]

    plt.figure(figsize=(9, 6))
    plt.barh(top["feature"], top["importance_mean"])
    plt.xlabel("Permutation Importance: Mean Decrease in F1-score")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.savefig(output_dir / "Fig4_Permutation_Feature_Importance.png", dpi=300, bbox_inches="tight")
    plt.close()


def plot_correlation_heatmap(data: pd.DataFrame, output_dir: Path) -> None:
    numeric_cols = [
        col
        for col in [
            "age",
            "annual_income",
            "emp_length",
            "loan_amount",
            "loan_int_rate",
            "loan_percent_income",
            "cred_length",
            "credit_score",
        ]
        if col in data.columns
    ]

    if len(numeric_cols) < 2:
        return

    corr = data[numeric_cols].corr(numeric_only=True)

    plt.figure(figsize=(10, 8))
    plt.imshow(corr, interpolation="nearest")
    plt.colorbar()
    plt.xticks(np.arange(len(numeric_cols)), numeric_cols, rotation=90)
    plt.yticks(np.arange(len(numeric_cols)), numeric_cols)

    for i in range(len(numeric_cols)):
        for j in range(len(numeric_cols)):
            plt.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", fontsize=8)

    plt.tight_layout()
    plt.savefig(output_dir / "Fig5_Correlation_Heatmap.png", dpi=300, bbox_inches="tight")
    plt.close()


def compute_feature_importance(
    best_pipeline: ImbPipeline,
    X_test: pd.DataFrame,
    y_test: np.ndarray,
    config: ExperimentConfig,
) -> pd.DataFrame:
    sample_size = min(config.importance_sample_size, len(X_test))
    X_sample = X_test.sample(n=sample_size, random_state=config.seed)
    y_sample = y_test[X_sample.index]

    print(f"[INFO] Computing permutation importance on {sample_size} samples")
    perm = permutation_importance(
        best_pipeline,
        X_sample,
        y_sample,
        scoring="f1",
        n_repeats=config.n_repeats_importance,
        random_state=config.seed,
        n_jobs=-1,
    )

    importance_df = pd.DataFrame(
        {
            "feature": X_sample.columns.tolist(),
            "importance_mean": perm.importances_mean,
            "importance_std": perm.importances_std,
        }
    ).sort_values("importance_mean", ascending=False)

    return importance_df


def run_experiment(config: ExperimentConfig) -> None:
    set_seed(config.seed)
    config.output_dir.mkdir(parents=True, exist_ok=True)
    figures_dir = config.output_dir / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)

    data_raw, dataset_summary = load_and_merge_datasets(config)
    data = clean_merged_data(data_raw)

    dataset_summary.to_csv(config.output_dir / "dataset_summary.csv", index=False)
    data.to_csv(config.output_dir / "merged_standardized_credit_data.csv", index=False)

    X_all = data.drop(columns=["default"])
    y_all = data["default"].astype(int).values
    sources = data["source_dataset"].astype(str).values

    X_features = X_all.drop(columns=["source_dataset"], errors="ignore")
    preprocessor = make_preprocessor(X_features)
    models = get_models(config.seed)

    results: List[Dict[str, object]] = []
    trained_random_split_pipelines: Dict[str, ImbPipeline] = {}

    # Experiment 1: Stratified random split
    (
        X_train,
        X_test,
        y_train,
        y_test,
        src_train,
        src_test,
    ) = train_test_split(
        X_features,
        y_all,
        sources,
        test_size=config.test_size,
        random_state=config.seed,
        stratify=y_all,
    )

    print("=" * 90)
    print("[INFO] Experiment 1: stratified_random")
    print("[INFO] Train distribution:", pd.Series(y_train).value_counts().to_dict())
    print("[INFO] Test distribution: ", pd.Series(y_test).value_counts().to_dict())

    for model_name, model in models.items():
        print(f"[INFO] Training {model_name}")
        result, trained_pipeline = evaluate_model(
            model_name,
            model,
            preprocessor,
            X_train,
            X_test,
            y_train,
            y_test,
            "stratified_random",
            config.seed,
        )
        results.append(result)
        trained_random_split_pipelines[model_name] = trained_pipeline

    # Experiment 2: Leave-one-dataset-out
    print("=" * 90)
    print("[INFO] Experiment 2: leave_one_dataset_out")

    unique_sources = sorted(pd.Series(sources).unique().tolist())

    for held_out_source in unique_sources:
        train_mask = sources != held_out_source
        test_mask = sources == held_out_source

        X_train_lodo = X_features.loc[train_mask]
        X_test_lodo = X_features.loc[test_mask]
        y_train_lodo = y_all[train_mask]
        y_test_lodo = y_all[test_mask]

        if len(np.unique(y_train_lodo)) < 2 or len(np.unique(y_test_lodo)) < 2:
            print(f"[WARN] Skipping {held_out_source}: one class only in train or test.")
            continue

        print("-" * 90)
        print(f"[INFO] Held-out dataset: {held_out_source}")
        print("[INFO] Train distribution:", pd.Series(y_train_lodo).value_counts().to_dict())
        print("[INFO] Test distribution: ", pd.Series(y_test_lodo).value_counts().to_dict())

        for model_name, model in models.items():
            print(f"[INFO] Training {model_name}")
            result, _ = evaluate_model(
                model_name,
                model,
                preprocessor,
                X_train_lodo,
                X_test_lodo,
                y_train_lodo,
                y_test_lodo,
                f"leave_one_dataset_out_{held_out_source}",
                config.seed,
            )
            results.append(result)

    results_df = pd.DataFrame(results)
    results_df.to_csv(config.output_dir / "creditfusion_model_results.csv", index=False)

    best_by_split = (
        results_df.sort_values(["split", "f1"], ascending=[True, False])
        .groupby("split")
        .head(3)
    )
    best_by_split.to_csv(config.output_dir / "creditfusion_best_by_split.csv", index=False)

    print("=" * 90)
    print("[INFO] Best three models by split")
    print(best_by_split)

    # Feature importance for best stratified random model
    random_results = results_df[results_df["split"] == "stratified_random"].copy()
    if not random_results.empty:
        best_row = random_results.sort_values("f1", ascending=False).iloc[0]
        best_model_name = str(best_row["model"])
        best_pipeline = trained_random_split_pipelines[best_model_name]

        importance_df = compute_feature_importance(best_pipeline, X_test, y_test, config)
        importance_df.to_csv(config.output_dir / "creditfusion_feature_importance.csv", index=False)
        plot_feature_importance(importance_df, figures_dir)

    # Figures
    plot_stratified_comparison(results_df, figures_dir)
    plot_cross_dataset_robustness(best_by_split, figures_dir)
    plot_correlation_heatmap(X_train, figures_dir)

    print("=" * 90)
    print(f"[DONE] Outputs saved to: {config.output_dir.resolve()}")


def parse_args() -> ExperimentConfig:
    parser = argparse.ArgumentParser(description="CreditFusion-XAI experiment runner")

    parser.add_argument("--output-dir", type=str, default="outputs", help="Output directory")
    parser.add_argument(
        "--max-rows-per-dataset",
        type=str,
        default="30000",
        help="Rows sampled from each dataset. Use 'None' for all rows.",
    )
    parser.add_argument("--test-size", type=float, default=0.20, help="Test split size")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument(
        "--n-repeats-importance",
        type=int,
        default=5,
        help="Permutation importance repeats",
    )
    parser.add_argument(
        "--importance-sample-size",
        type=int,
        default=5000,
        help="Sample size for permutation importance",
    )

    args = parser.parse_args()

    max_rows = None if args.max_rows_per_dataset.lower() == "none" else int(args.max_rows_per_dataset)

    return ExperimentConfig(
        output_dir=Path(args.output_dir),
        max_rows_per_dataset=max_rows,
        test_size=args.test_size,
        seed=args.seed,
        n_repeats_importance=args.n_repeats_importance,
        importance_sample_size=args.importance_sample_size,
    )


if __name__ == "__main__":
    run_experiment(parse_args())
